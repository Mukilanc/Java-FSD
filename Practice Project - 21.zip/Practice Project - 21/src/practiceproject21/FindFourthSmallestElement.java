package practiceproject21;

import java.util.Arrays;

public class FindFourthSmallestElement {
    public static void main(String[] args) {
        int[] arr = {5, 3, 2, 1, 4};
        int fourthSmallestElement = findFourthSmallestElement(arr);

        System.out.println("The fourth smallest element in the array is: " + fourthSmallestElement);
    }

    private static int findFourthSmallestElement(int[] arr) {
        Arrays.sort(arr);
        return arr[3];
    }
}