package models.questions;

public enum QuestionType {
	MCQ, FillInBlank, Scale, Open
}
