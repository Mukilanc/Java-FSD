package com.xadmin.productmanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.xadmin.productmanagement.bean.Product;

public class UserDao {

	private String jdbcURL = "jdbc:mysql://localhost:3306/userdb?useSSL=false";
	//private String jdbcURL = "jdbc:mysql://localhost:3306/?user=root";
	private String jdbcUsername = "root";
	private String jdbcPassword = "Nirmala@1973";
	//private String jdbcDriver = "com.mysql.jdbc.Driver";
	
	private static final String INSERT_USERS_SQL = "INSERT INTO products" + "(name,type,price) VALUES" + "(?,?,?);";
	
	
	private static final String SELECT_PRODUCT_BY_ID = "select id, name, type, price from products where id = ?";
	private static final String SELECT_ALL_USERS = "select * from products";
	private static final String DELETE_USERS_SQL = "delete from products where id = ?";
	private static final String UPDATE_USERS_SQL = "update products set name = ?, type = ?, price = ? where id = ?";
	public UserDao()
	{
		
	}
	
	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	
	//Insert User
	public void insertUser(Product product) {
		
		System.out.println(INSERT_USERS_SQL);
		try(Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)){
			preparedStatement.setString(1, product.getName());
			preparedStatement.setString(2, product.getType());
			preparedStatement.setString(3, product.getPrice());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		}catch (SQLException e)
		{
			printSQLException(e);
		}
		
		}

	
	//Select User by ID
	public Product selectuser(int id) {
		Product product = null;
		try(Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PRODUCT_BY_ID);) {
			
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				String name = rs.getString("name");
				String type = rs.getString("type");
				String price = rs.getString("price");
				product = new Product (id,name,type,price);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			printSQLException(e);
		}
		return product;
	}
	
	//Select all users
	public List<Product> selectAllUsers(){
		
		List<Product> products = new ArrayList<>();
		try(Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);){
			
			System.out.println(preparedStatement);
			
			ResultSet rs = preparedStatement.executeQuery();
			
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String type = rs.getString("type");
				String price = rs.getString("price");
				products.add(new Product(id,name,type,price));
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			printSQLException(e);
		}
		
		return products;
	}
	
	
	//Update User
	public boolean updateUser(Product product) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);)
		{
			System.out.println("updated User:" + statement);
			statement.setString(1,  product.getName());
			statement.setString(2,  product.getType());
			statement.setString(3,  product.getPrice());
			statement.setInt(4, product.getId());
			
			rowUpdated = statement.executeUpdate()>0;
		}
		return rowUpdated;
	}
	
	//delete User method
	public boolean deleteUser(int id) throws SQLException{
		boolean rowDeleted;
		try(Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);){
			
			statement.setInt(1,  id);
			rowDeleted = statement.executeUpdate() > 0;
			
		}
		return rowDeleted;
	}
	
	private void printSQLException(SQLException ex) {

		for (Throwable e : ex) {
			if(e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState:" + ((SQLException)e).getSQLState());
				System.err.println("Error Code:" + ((SQLException)e).getErrorCode());
				System.err.println("Message:" + e.getMessage());
				
				Throwable t = ex.getCause();
				while(t != null) {
					System.out.println("Cause:" + t);
					t = t.getCause();
					}
			}
		}
	}
}
	

	

	

	

	
	

