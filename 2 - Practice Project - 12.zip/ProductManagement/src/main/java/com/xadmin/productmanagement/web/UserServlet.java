package com.xadmin.productmanagement.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xadmin.productmanagement.bean.Product;
import com.xadmin.productmanagement.dao.UserDao;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao;
       

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init() throws ServletException {
		userDao = new UserDao();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getServletPath();
		switch (action)
		{
		case"/new":
			showNewForm(request, response);
			break;
		case"/insert":
			insertUser(request, response);
			break;
		case"/delete":
			deleteUser(request, response);
			break;
		case"/edit":
			showEditForm(request, response);
			break;
		case"/update":
			try {
				updateUser(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			listProduct(request, response);
			break;
		}
	}


	private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		dispatcher.forward(request, response);
		
	}
	
	private void insertUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String price = request.getParameter("price");
		
		Product newProduct = new Product(name,type,price);
		
		userDao.insertUser(newProduct);
		response.sendRedirect("list");
	}
	
	private void deleteUser (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		//Product newProduct = new Product (id);
		try {
			userDao.deleteUser(id);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		response.sendRedirect("list");
	}
	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
	{
		int id = Integer.parseInt(request.getParameter("id"));
		
		Product existingProduct;
		try {
			existingProduct = userDao.selectuser(id);
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
			request.setAttribute("product", existingProduct);
			dispatcher.forward(request, response);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException
	{
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String type = request.getParameter("type");
		String price = request.getParameter("price");
		
		Product product = new Product(name, type, price);
		userDao.updateUser(product);
		response.sendRedirect("list");
	}
	
	private void listProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try {
			List <Product> listProduct = userDao.selectAllUsers();
			request.setAttribute("listProduct", listProduct);
			RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
			dispatcher.forward(request, response);
		}
		catch (Exception e)
		{
		e.printStackTrace();	
		}
		}
}
