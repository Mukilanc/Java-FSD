package sessionTracking;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/HomeServlet")
public class HomeServlet extends HttpServlet {
	 @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	        PrintWriter out = resp.getWriter();

	        // Get the username from the session
	        HttpSession session = req.getSession();
	        String username = (String) session.getAttribute("username");

	        // If the username is null, redirect the user to the login page
	        if (username == null) {
	            resp.sendRedirect("/login");
	            return;
	        }

	        // Display a message to the user
	        out.println("<h1>Welcome, " + username + "!</h1>");
	    }

}
