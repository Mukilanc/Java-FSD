package loginServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();

        // Get the username and password from the request
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // Validate the username and password
        // ...

        // If the username and password are valid, create a session and store the username in it
        HttpSession session = req.getSession();
        session.setAttribute("username", username);

        // Redirect the user to the home page
        resp.sendRedirect("/home");
    }

}
