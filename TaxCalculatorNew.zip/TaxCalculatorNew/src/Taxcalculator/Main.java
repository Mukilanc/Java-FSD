package Taxcalculator;

import java.util.*;


public class Main {
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {

		System.out.println("+------------------------------------------+");
		System.out.printf("| %-40s |\n", "       Welcome to Tax Calculator" );
		System.out.println("+------------------------------------------+");
		
		System.out.printf("| %-40s |","       Developed by Mukilan C","\n");
		
		String loginId = "Mukilan";
		String Pass = "1234";
		
		System.out.printf("\nEnter Your Login ID:");

		String userid = scanner.nextLine();
		System.out.printf("Enter Your Password:");
		String password = scanner.nextLine();
		
		if (userid.equals(loginId) && password.equals(Pass))
		{
			Menu();
		}
		else
		{
			System.out.println("Login Failed!");
			//welcome();
			//break;
		}
	}
	
	public static void Menu() {
		System.out.println("\nChoose Tax Type:\n1. Property Tax\n2. Vehicle Tax\n3. Total\n4. Exit");
		int choice = scanner.nextInt();
		switch(choice)
		{
		case 1:
			propertyTaxConstructor.propertySubMenu();
			break;
		case 2:
			vehicleTaxConstructor.vehicleSubMenu();
			break;
		case 3:
			totalTaxNew.totalTax();
			break;
		case 4:
			System.out.println("Thankyou for using Tax Calculator!");
			break;
		default:
			System.out.println("Wrong Choice! please make right choice from the list.");
			//welcome();
			break;
		}
	}
}
