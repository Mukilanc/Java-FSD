package Taxcalculator;

public class totalTaxNew {

	public static void totalTax() {
		/*
		 * System.out.println("Total Property Tax: " +
		 * propertyTaxConstructor.totalPropertyTax());
		 * System.out.println("Total Vehicle Tax: " +
		 * vehicleTaxConstructor.totalVehicleTax());
		 * 
		 *  System.out.println(totalTax);
		 */
		
		int count = 1;
		double totalTax = propertyTaxConstructor.totalPropertyTax() + vehicleTaxConstructor.totalVehicleTax();
		System.out.println("------------------------------------------------------");
        System.out.printf("%-10s %-15s %-15s%n", "ID", "PARTICULAR", "TOTAL");
        System.out.println("------------------------------------------------------");
        System.out.printf("%-10d %-15s Rs.%-15.2f %n", count++, "Property" , propertyTaxConstructor.totalPropertyTax());
        System.out.printf("%-10d %-15s Rs.%-15.2f %n", count++, "Vehicle" , vehicleTaxConstructor.totalVehicleTax());
        System.out.println("------------------------------------------------------");
        System.out.println("                    Total = " + totalTax);
	}
}
