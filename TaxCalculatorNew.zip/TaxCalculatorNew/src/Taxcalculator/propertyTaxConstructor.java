package Taxcalculator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class propertyTaxConstructor {

	    private int serialNumber;
	    private double builtUpArea;
	    private double baseValue;
	    private double ageFactor;
	    public boolean isInCity;
	    private double propertyTax;

	    public propertyTaxConstructor(int serialNumber, double builtUpArea, double baseValue, double ageFactor, boolean isInCity) {
	        this.serialNumber = serialNumber;
	        this.builtUpArea = builtUpArea;
	        this.baseValue = baseValue;
	        this.ageFactor = ageFactor;
	        this.isInCity = isInCity;
	    }

	    public int getSerialNumber() {
	        return serialNumber;
	    }

	    public double getBuiltUpArea() {
	        return builtUpArea;
	    }

	    public double getBaseValue() {
	        return baseValue;
	    }

	    public double getAgeFactor() {
	        return ageFactor;
	    }

	    public boolean isInCity() {
	        return isInCity;
	    }

	    public double getPropertyTax() {
	        return propertyTax;
	    }

	    public void setPropertyTax(double propertyTax) {
	        this.propertyTax = propertyTax;
	    
	    }
	    
	    static List<propertyTaxConstructor> propertyList = new ArrayList<>();
	    
	    public static void propertySubMenu()
		{
			Scanner scanner = new Scanner(System.in);
	        //List<propertyTaxConstructor> propertyList = new ArrayList<>();
	        int serialNumber = 1;

	        while (true) {
	            System.out.println("Property Tax Calculator");
	            System.out.println("1. Add Property Details");
	            System.out.println("2. Calculate Property Tax");
	            System.out.println("3. Display Property Details");
	            System.out.println("4. Return to Main menu");
	            System.out.print("Select an option: ");
	            int option = scanner.nextInt();
	            scanner.nextLine();

	            switch (option) {
	                case 1:
	                    System.out.print("Enter built-up area (in square feet): ");
	                    double builtUpArea = scanner.nextDouble();
	                    System.out.print("Enter base value: ");
	                    double baseValue = scanner.nextDouble();
	                    System.out.print("Enter age factor: ");
	                    double ageFactor = scanner.nextDouble();
	                    System.out.print("Is the property in the city? (true/false): ");
	                    boolean isInCity = scanner.nextBoolean();

	                    propertyTaxConstructor property = new propertyTaxConstructor(serialNumber++, builtUpArea, baseValue, ageFactor, isInCity);
	                    propertyList.add(property);

	                    System.out.println("\nProperty details added.\n");
	                    break;

	                case 2:
	                    if (propertyList.isEmpty()) {
	                        System.out.println("No property details available. Please add property details first.");
	                    } else {
	                        System.out.println("\nCalculating property tax for the latest property details.\n");
	                        propertyTaxConstructor latestProperty = propertyList.get(propertyList.size() - 1);
	                        double propertyTax;
	                        if (latestProperty.isInCity == true) {
	                            propertyTax = (latestProperty.getBuiltUpArea() * latestProperty.getAgeFactor() * latestProperty.getBaseValue()) + (0.5 * latestProperty.getBuiltUpArea());
	                        } else {
	                            propertyTax = latestProperty.getBuiltUpArea() * latestProperty.getAgeFactor() * latestProperty.getBaseValue();
	                        }
	                        latestProperty.setPropertyTax(propertyTax);
	                        System.out.println("\nProperty Tax: Rs." + propertyTax + "\n");
	                        //double totalPropertyTax = calculateTotalPropertyTax(propertyList);
	                        //System.out.println("\nTotal Property Tax: Rs." + totalPropertyTax + "\n");
	                    }
	                    break;

	                case 3:
	                    if (propertyList.isEmpty()) {
	                        System.out.println("No property details available.");
	                    } else {
	                        System.out.println("\nProperty Details:\n");
	                        System.out.println("-------------------------------------------------------------------------------------------");
	                        System.out.printf("%-10s %-15s %-15s %-15s %-15s %-15s%n", "Serial", "Built-up Area", "Base Value", "Age Factor", "In City", "Property Tax");
	                        System.out.println("-------------------------------------------------------------------------------------------");
	                        for (propertyTaxConstructor propertyDetail : propertyList) {
	                            System.out.printf("%-10d %-15.2f Rs.%-15.2f %-15.2f%-15s Rs.%-15.2f%n",
	                                    propertyDetail.getSerialNumber(), propertyDetail.getBuiltUpArea(),
	                                    propertyDetail.getBaseValue(), propertyDetail.getAgeFactor(),
	                                    propertyDetail.isInCity(), propertyDetail.getPropertyTax());
	                        }
	                        System.out.println("-------------------------------------------------------------------------------------------");
	                    }
	                    break;

	                case 4:
	                	Main.Menu();
	                    return;

	                default:
	                    System.out.println("Invalid option. Please select a valid option.");
	            }
	        }
		}
	    
	   public static double totalPropertyTax() {
	    	
		   double totalProperty = 0.00;
		   
		   for (propertyTaxConstructor propertyDetail : propertyList) {
			totalProperty+=propertyDetail.getPropertyTax();
		}
		   return totalProperty;
		   
	   }
	   
	   
}
