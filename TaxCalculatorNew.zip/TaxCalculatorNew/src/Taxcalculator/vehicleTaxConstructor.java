package Taxcalculator;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class vehicleTaxConstructor {
	private int serialNumber;
    private String regNumber;
    private String brand;
    private double purchaseCost;
    private int maxVelocity;
    private int capacity;
    private String vehicleType;
    private double vehicleTax;

    public vehicleTaxConstructor(int serialNumber, String regNumber, String brand, double purchaseCost, int maxVelocity, int capacity, String vehicleType, double vehicleTax) {
        this.serialNumber = serialNumber;
        this.regNumber = regNumber;
        this.brand = brand;
        this.purchaseCost = purchaseCost;
        this.maxVelocity = maxVelocity;
        this.capacity = capacity;
        this.vehicleType = vehicleType;
        this.vehicleTax = vehicleTax;
    }

    public int getSerialNumber() {
        return serialNumber;
    }

    public String getRegNumber() {
        return regNumber;
    }

    public String getBrand() {
        return brand;
    }

    public double getPurchaseCost() {
        return purchaseCost;
    }

    public int getMaxVelocity() {
        return maxVelocity;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public double getVehicleTax() {
        return vehicleTax;
    }

    public void setVehicleTax(double vehicleTax) {
        this.vehicleTax = vehicleTax;
    }
    
    private static double calculateVehicleTax(String vehicleType, int maxVelocity, int capacity, double purchaseCost) {
        double taxPercentage = 0.0;
        switch (vehicleType.toLowerCase()) {
            case "petrol":
                taxPercentage = 0.10;
                break;
            case "diesel":
                taxPercentage = 0.11;
                break;
            case "cng":
            case "lpg":
                taxPercentage = 0.12;
                break;
            default:
                System.out.println("Invalid vehicle type. Assuming petrol with 10% tax.");
                taxPercentage = 0.10;
                break;
        }
        return maxVelocity + capacity + (taxPercentage * purchaseCost);
    }
    static List<vehicleTaxConstructor> vehicleList = new ArrayList<>();
	public static void vehicleSubMenu() {

		Scanner scanner = new Scanner(System.in);
        //List<vehicleTaxConstructor> vehicleList = new ArrayList<>();
        int serialNumber = 1;

        while (true) {
            System.out.println("Tax Calculator");
            System.out.println("1. Add Vehicle Details");
            System.out.println("2. Calculate Vehicle Tax");
            System.out.println("3. Display Vehicle Details");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            switch (option) {
                case 1:
                    System.out.print("Enter registration number: ");
                    String regNumber = scanner.nextLine();
                    System.out.print("Enter brand: ");
                    String brand = scanner.nextLine();
                    System.out.print("Enter purchase cost: ");
                    double purchaseCost = scanner.nextDouble();
                    System.out.print("Enter maximum velocity: ");
                    int maxVelocity = scanner.nextInt();
                    System.out.print("Enter capacity (number of seats): ");
                    int capacity = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter type of vehicle (petrol/diesel/CNG/LPG): ");
                    String vehicleType = scanner.nextLine();

                    double vehicleTax = calculateVehicleTax(vehicleType, maxVelocity, capacity, purchaseCost);
                    vehicleTaxConstructor vehicle = new vehicleTaxConstructor(serialNumber++, regNumber, brand, purchaseCost, maxVelocity, capacity, vehicleType, vehicleTax);
                    vehicleList.add(vehicle);

                    System.out.println("\nVehicle details added.\n");
                    break;

                case 2:
                    if (vehicleList.isEmpty()) {
                        System.out.println("\nNo vehicle details available. Please add vehicle details first.\n");
                    } else {
                        System.out.println("\nalculating vehicle tax for the latest vehicle details.\n");
                        vehicleTaxConstructor latestVehicle = vehicleList.get(vehicleList.size() - 1);
                        double vehicleTax1 = calculateVehicleTax(latestVehicle.getVehicleType(), latestVehicle.getMaxVelocity(), latestVehicle.getCapacity(), latestVehicle.getPurchaseCost());
                        latestVehicle.setVehicleTax(vehicleTax1); // Store vehicle tax
                        System.out.println("Vehicle Tax: Rs." + vehicleTax1);
                    }
                    break;

                case 3:
                	if (vehicleList.isEmpty()) {
                        System.out.println("\nNo vehicle details available.\n");
                    } else {
                        System.out.println("\nVehicle Details:\n");
                        System.out.println("-------------------------------------------------------------------------------------------------------------------");
                        System.out.printf("%-10s %-15s %-15s %-15s %-15s %-15s %-15s %-15s%n", "ID", "Reg Number", "Brand", "Purchase Cost", "Max Velocity", "Capacity", "Vehicle Type", "Vehicle Tax");
                        System.out.println("-------------------------------------------------------------------------------------------------------------------");
                        for (vehicleTaxConstructor vehicleDetail : vehicleList) {
                            System.out.printf("%-10d %-15s %-15s Rs.%-15.2f %-15d %-15d %-15s Rs.%-15.2f%n",
                                    vehicleDetail.getSerialNumber(), vehicleDetail.getRegNumber(), vehicleDetail.getBrand(),
                                    vehicleDetail.getPurchaseCost(), vehicleDetail.getMaxVelocity(),
                                    vehicleDetail.getCapacity(), vehicleDetail.getVehicleType(), vehicleDetail.getVehicleTax());
                        }
                        System.out.println("-------------------------------------------------------------------------------------------------------------------");
                    }
                    break;

                case 4:
                	Main.Menu();
                    return;

                default:
                    System.out.println("Invalid option. Please select a valid option.");
            }
        }
	
	}
	
	   public static double totalVehicleTax() {
	    	
		   double totalProperty = 0.00;
		   
		   for (vehicleTaxConstructor vehicleDetail : vehicleList) {
			totalProperty+=vehicleDetail.getVehicleTax();
		}
		   return totalProperty;
		   
	   }
}
