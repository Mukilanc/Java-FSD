package practiceproject26;

public class DoublyLinkedListTraversal {
    public static void main(String[] args) {

        DoublyLinkedList doublyLinkedList = new DoublyLinkedList();
        doublyLinkedList.insert(1);
        doublyLinkedList.insert(2);
        doublyLinkedList.insert(3);
        doublyLinkedList.insert(4);
        doublyLinkedList.insert(5);

        System.out.println("Doubly linked list in the forward direction: ");
        doublyLinkedList.traverseForward();

        System.out.println("Doubly linked list in the backward direction: ");
        doublyLinkedList.traverseBackward();
    }
}

class Node {
    int data;
    Node next;
    Node previous;

    public Node(int data) {
        this.data = data;
        this.next = null;
        this.previous = null;
    }
}

class DoublyLinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node currentNode = head;
            while (currentNode.next != null) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            newNode.previous = currentNode;
        }
    }

    public void traverseForward() {
        Node currentNode = head;
        while (currentNode != null) {
            System.out.print(currentNode.data + " ");
            currentNode = currentNode.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        Node currentNode = head;
        while (currentNode.next != null) {
            currentNode = currentNode.next;
        }

        while (currentNode != null) {
            System.out.print(currentNode.data + " ");
            currentNode = currentNode.previous;
        }
        System.out.println();
    }
}