package practiceproject27;

class Stack {
    int[] items;
    int top;

    public Stack(int size) {
        items = new int[size];
        top = -1;
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == items.length - 1;
    }

    public void push(int item) throws Exception {
        if (isFull()) {
            throw new Exception("Stack is full");
        }

        top++;
        items[top] = item;
    }

    public int pop() throws Exception {
        if (isEmpty()) {
            throw new Exception("Stack is empty");
        }

        int item = items[top];
        top--;
        return item;
    }

    public int peek() throws Exception {
        if (isEmpty()) {
            throw new Exception("Stack is empty");
        }

        return items[top];
    }

    public void printStack() {
        for (int i = top; i >= 0; i--) {
            System.out.print(items[i] + " ");
        }
        System.out.println();
    }


    public static void main(String[] args) throws Exception {
        Stack stack = new Stack(10);

        stack.push(1);
        stack.push(2);
        stack.push(3);

        stack.printStack();

        int removedElement = stack.pop();

        stack.printStack();
    }
}