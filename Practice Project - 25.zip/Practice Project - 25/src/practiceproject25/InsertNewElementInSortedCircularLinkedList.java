package practiceproject25;

public class InsertNewElementInSortedCircularLinkedList {
    public static void main(String[] args) {

        CircularLinkedList circularLinkedList = new CircularLinkedList();
        circularLinkedList.insert(1);
        circularLinkedList.insert(2);
        circularLinkedList.insert(3);
        circularLinkedList.insert(4);
        circularLinkedList.insert(5);

        System.out.println("Circular linked list before inserting a new element: ");
        circularLinkedList.print();

        circularLinkedList.insertNewElementInSortedCircularLinkedList(6);

        System.out.println("Circular linked list after inserting a new element: ");
        circularLinkedList.print();
    }
}

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
        } else {
            Node currentNode = head;
            while (currentNode.next != head) {
                currentNode = currentNode.next;
            }
            currentNode.next = newNode;
            newNode.next = head;
        }
    }

    public void insertNewElementInSortedCircularLinkedList(int newElement) {
        Node currentNode = head;
        Node previousNode = null;
        while (currentNode.next != head && currentNode.data <= newElement) {
            previousNode = currentNode;
            currentNode = currentNode.next;
        }

        if (previousNode == null) {
            Node newNode = new Node(newElement);
            newNode.next = head;
            head = newNode;
        } else {
            Node newNode = new Node(newElement);
            newNode.next = previousNode.next;
            previousNode.next = newNode;
        }
    }

    public void print() {
        Node currentNode = head;
        while (currentNode.next != head) {
            System.out.print(currentNode.data + " ");
            currentNode = currentNode.next;
        }
        System.out.print(currentNode.data + " ");
        System.out.println();
    }
}