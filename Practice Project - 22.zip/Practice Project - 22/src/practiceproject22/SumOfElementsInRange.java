package practiceproject22;

public class SumOfElementsInRange {
    public static void main(String[] args) {
        int n = 10;
        int L = 2;
        int R = 6;

        int sum = sumOfElementsInRange(n, L, R);

        System.out.println("The sum of n number of elements in the range of L and R is: " + sum);
    }

    private static int sumOfElementsInRange(int n, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += i;
        }
        return sum;
    }
}