package trackingSession;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();

        // Get the username and password from the request
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // Create a cookie to store the username
        Cookie cookie = new Cookie("username", username);
        cookie.setMaxAge(60 * 60); // Set the cookie to expire in 1 hour
        resp.addCookie(cookie);

        // Redirect the user to the home page
        resp.sendRedirect("/home");
    }
}
