package trackingSession;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javaxservlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LogoutServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Delete the username cookie
        Cookie usernameCookie = new Cookie("username", "");
        usernameCookie.setMaxAge(0); // Set the cookie to expire immediately
        resp.addCookie(usernameCookie);

        // Redirect the user to the login page
        resp.sendRedirect("/login");
    }
}
