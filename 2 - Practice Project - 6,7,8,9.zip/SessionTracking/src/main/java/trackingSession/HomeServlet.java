package trackingSession;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out = resp.getWriter();

        // Get the username cookie
        Cookie[] cookies = req.getCookies();
        Cookie usernameCookie = null;
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("username")) {
                usernameCookie = cookie;
                break;
            }
        }

        // If the username cookie is not found, redirect the user to the login page
        if (usernameCookie == null) {
            resp.sendRedirect("/login");
            return;
        }

        // Get the username from the cookie
        String username = usernameCookie.getValue();

        // Display a message to the user
        out.println("<h1>Welcome, " + username + "!</h1>");
    }
}
