package javaxservlet.http;

public class HttpServletRequest {

}
